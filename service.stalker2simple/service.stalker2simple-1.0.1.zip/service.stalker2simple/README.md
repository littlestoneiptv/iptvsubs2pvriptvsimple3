service.stalker2simple
========================

Update EPG of Stalker for PVR IPTV Simple.<br>

This is a mod on Psyc0n's EPG updater (GPLv2) to work with IPTV Stalker Generic client. It creates a m3u file for the PVR IPTV Simple, downloads EPG, and set up PVR IPTV Simple.
