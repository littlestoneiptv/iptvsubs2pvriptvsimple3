service.iptvsubs2pvriptvsimple
==============================

Update EPG of IPTVSubs for PVR IPTV Simple.<br>

This is a mod on the beta version of psycon's IPTVsubs EPG updater to match with IPTVsubs addon 2.7. It creates a m3u file for the PVR IPTV Simple with mapped EPG and channel logo.
