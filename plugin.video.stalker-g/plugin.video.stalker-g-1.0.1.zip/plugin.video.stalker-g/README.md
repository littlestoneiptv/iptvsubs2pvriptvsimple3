# plugin.video.stalker-g

Kodi Stalker Generic Video add-on - all platforms
Modified based on Stalker Plus Lite

From Forum
http://iptvtalk.org